@echo off
cd /d "%~dp0"
python csv_ceviri_editor.py
pause
