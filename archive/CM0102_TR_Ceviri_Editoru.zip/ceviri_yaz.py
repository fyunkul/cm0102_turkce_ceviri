# -*- coding: utf-8 -*-
"""
CM0102 Turkce ceviri yazici.
Kullanim:
  python ceviri_yaz.py ORIJINAL.ldb ceviriler.xlsx CIKTI.ldb --satir 1-500
  python ceviri_yaz.py ORIJINAL.ldb ceviriler.xlsx CIKTI.ldb --satir 1-500,900-950
  python ceviri_yaz.py ORIJINAL.ldb ceviriler.xlsx CIKTI.ldb --grup 3398-3650
  python ceviri_yaz.py ORIJINAL.ldb ceviriler.xlsx CIKTI.ldb --hepsi
Secenekler:
  Degisken etiketleri (<%s - ...>) cumlede istenen sirada olabilir; oyunun sira tablosu otomatik yazilir.
  --guvenli   Sadece Turkce metni orijinal Norvecce metinden uzun olmayan satirlari yazar.
ORIJINAL.ldb dosyasina asla yazmaz; her zaman yeni bir CIKTI.ldb uretir.
"""
import sys, re, argparse

EXPECT_SIZE = 205757382
TAG = re.compile(r'<\s*%[^>]*>')
SUBS = str.maketrans({'ş':'s','Ş':'S','ğ':'g','Ğ':'G','ı':'i','İ':'I'})

# ---- yazma cekirdegi: Norvecce metin + degisken sira tablosu ----
TAGX = re.compile(r'<\s*%[^>]*>|<ARG>')
FFRUN = re.compile(rb'\xff{15,}')
def tnorm(t): return re.sub(r'\s+', ' ', t).strip()

def slot_info(data, ofs):
    """Norvecce alan bilgisi: (metin, slot_sonu, eski_perm, eski_tablo_baslangici)"""
    q = data.index(b'\x00', ofs); text = data[ofs:q]
    m = FFRUN.search(data, ofs, ofs + 2400)
    nf = m.start() if m else None
    if nf is None: return text, None, [], None
    k = text.count(b'\x08'); t = nf - 1 - 4 * k
    if data[t] == 0x20:
        perm = [int.from_bytes(data[t+1+4*i:t+5+4*i], 'little') for i in range(k)]
        return text, nf, perm, t
    return text, nf, [], None      # bos alan: tablo yok

def eng_tags(en):
    return [tnorm(t) for t in re.findall(r'<\s*%[^>]*>', en)]

def build_v2(turkce, en, data, ofs):
    """-> (yazilacak [(ofs, bytes)], durum, metin_bayt, kapasite)"""
    text0, nf, perm0, tstart = slot_info(data, ofs)
    if nf is None: return None, 'HATA: alan sonu bulunamadi', 0, 0
    t = (turkce or '').replace('\r\n', '\n').replace('\r', '\n')
    if not t.strip(): return None, 'bos', 0, nf - ofs
    while t.startswith('\n\n'): t = t[2:]
    et = eng_tags(en); used = [False] * len(et); perm = []; argi = 0
    parts = []; pos = 0
    for m in TAGX.finditer(t):
        parts.append(t[pos:m.start()]); pos = m.end()
        tg = m.group()
        if tg == '<ARG>':
            idx = None
            if argi < len(perm0) and perm0[argi] < len(et) and not used[perm0[argi]]: idx = perm0[argi]
            argi += 1
            if idx is None:
                idx = next((i for i in range(len(et)) if not used[i]), None)
        else:
            n = tnorm(tg); idx = next((i for i in range(len(et)) if et[i] == n and not used[i]), None)
            if idx is None:
                return None, 'HATA: ingilizcede olmayan ya da fazla etiket: %s' % tg[:40], 0, nf - ofs
        if idx is None: return None, 'HATA: degisken sayisi fazla (ingilizcede %d)' % len(et), 0, nf - ofs
        used[idx] = True; perm.append(idx); parts.append('\x08')
    parts.append(t[pos:])
    body = ''.join(parts).translate(SUBS).encode('cp1252', errors='replace')
    field = (b'\n\n' if text0.startswith(b'\n\n') else b'') + body + b'\x00'
    trailer = b' ' + b''.join(p.to_bytes(4, 'little') for p in perm)
    cap = nf - ofs - len(trailer)
    if len(field) > cap: return None, 'HATA: sigmiyor (%d > %d)' % (len(field), cap), len(field), cap
    zstart = min(tstart if tstart is not None else nf, nf - len(trailer))
    writes = [(ofs, field), (zstart, b'\x00' * (nf - len(trailer) - zstart) + trailer)]
    if ofs + len(field) > zstart: return None, 'HATA: sigmiyor', len(field), cap
    return writes, 'tamam', len(field), cap

def parse_ranges(s, maxn):
    out = set()
    for part in s.split(','):
        part = part.strip()
        if not part: continue
        if '-' in part:
            a, b = part.split('-', 1)
            out.update(range(int(a), int(b) + 1))
        else:
            out.add(int(part))
    return out

def _col(ref):
    n = 0
    for ch in ref:
        if ch.isalpha(): n = n * 26 + (ord(ch.upper()) - 64)
        else: break
    return n - 1

def read_xlsx(path):
    """Harici kutuphane gerektirmeden xlsx okur (zipfile + xml)."""
    import zipfile
    import xml.etree.ElementTree as ET
    ns = '{http://schemas.openxmlformats.org/spreadsheetml/2006/main}'
    z = zipfile.ZipFile(path)
    shared = []
    if 'xl/sharedStrings.xml' in z.namelist():
        root = ET.fromstring(z.read('xl/sharedStrings.xml'))
        for si in root.iter(ns + 'si'):
            shared.append(''.join(t.text or '' for t in si.iter(ns + 't')))
    sheet = 'xl/worksheets/sheet1.xml'
    if sheet not in z.namelist():
        names = sorted(n for n in z.namelist() if n.startswith('xl/worksheets/sheet'))
        sheet = names[0]
    out = []
    for _, el in ET.iterparse(z.open(sheet)):
        if el.tag == ns + 'row':
            row = {}
            for c in el.findall(ns + 'c'):
                t = c.get('t'); v = c.find(ns + 'v')
                if t == 'inlineStr':
                    val = ''.join(x.text or '' for x in c.iter(ns + 't'))
                elif v is None: val = None
                elif t == 's': val = shared[int(v.text)]
                elif t in ('str', 'e'): val = v.text
                elif t == 'b': val = v.text
                else:
                    val = v.text
                row[_col(c.get('r'))] = val
            out.append(row)
            el.clear()
    return out

def load_rows(path):
    data = read_xlsx(path)
    head_row = data[0]
    head = {str(v).strip(): k for k, v in head_row.items() if v is not None}
    need = ['Sira', 'Grup', 'Ofset', 'Kapasite', 'Dogrulama', 'Turkce']
    for n in need:
        if n not in head:
            print("Excel'de '%s' sutunu yok. Sutunlar: %s" % (n, list(head))); sys.exit(1)
    rows = []
    for r in data[1:]:
        g = lambda n: r.get(head[n])
        if g('Sira') is None: continue
        rows.append(dict(sira=int(float(g('Sira'))), grup=int(float(g('Grup'))), ofset=int(float(g('Ofset'))),
                         kap=int(float(g('Kapasite'))), dog=str(g('Dogrulama') or ''), tr=g('Turkce'), en=str(g('Ingilizce') or '') if 'Ingilizce' in head else '',
                         onay=bool('Onay' in head and r.get(head['Onay']))))
    return rows

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('ldb'); ap.add_argument('xlsx'); ap.add_argument('cikti')
    ap.add_argument('--satir', default=''); ap.add_argument('--grup', default=''); ap.add_argument('--hepsi', action='store_true')
    ap.add_argument('--guvenli', action='store_true')
    ap.add_argument('--sadece-onayli', action='store_true', help="Sadece Excel'de 'Onay' sutunu dolu olan satirlari yazar.")
    a = ap.parse_args()
    if not a.satir and not a.grup and not a.hepsi:
        print("--satir, --grup veya --hepsi vermelisiniz."); sys.exit(1)
    data = open(a.ldb, 'rb').read()
    if len(data) != EXPECT_SIZE:
        print("UYARI: dosya boyutu %d, beklenen %d. Orijinal language.ldb olmayabilir." % (len(data), EXPECT_SIZE))
        if input("Devam edilsin mi? (e/h) ").lower() != 'e': sys.exit(1)
    rows = load_rows(a.xlsx)
    sel = None if a.hepsi else parse_ranges(a.satir, len(rows))
    gsel = parse_ranges(a.grup, 0) if a.grup else None
    out = bytearray(data)
    wrote = skipped = 0; skip_notes = []
    for r in rows:
        if not a.hepsi:
            ok = (a.satir and r['sira'] in sel) or (gsel is not None and r['grup'] in gsel)
            if not ok: continue
        if a.sadece_onayli and not r['onay']:
            continue
        if r['tr'] is None or not str(r['tr']).strip():
            continue
        e = r['ofset']
        q = e
        while data[q] != 0: q += 1
        orig = data[e:q]
        if orig[:12].hex() != r['dog']:
            print("HATA: satir %d icin dosya Excel ile uyusmuyor (yanlis language.ldb?). Islem iptal." % r['sira']); sys.exit(1)
        writes, st, n, cap = build_v2(str(r['tr']), r['en'], data, e)
        if not writes:
            skipped += 1; skip_notes.append((r['sira'], n, cap, st)); continue
        if a.guvenli and n > len(orig) + 1:
            skipped += 1; skip_notes.append((r['sira'], n, len(orig) + 1, 'orijinalden uzun (guvenli mod)')); continue
        for o, b in writes: out[o:o + len(b)] = b
        wrote += 1
    open(a.cikti, 'wb').write(out)
    print("Yazilan satir: %d   Atlanan: %d" % (wrote, skipped))
    for s in skip_notes[:30]:
        print("  atlandi sira=%d: %d bayt > %d (%s)" % s)
    print("Cikti: " + a.cikti)

if __name__ == '__main__':
    main()
