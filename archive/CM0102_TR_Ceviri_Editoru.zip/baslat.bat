@echo off
cd /d "%~dp0"
py -3 ceviri_arayuz.py
if errorlevel 1 pause
