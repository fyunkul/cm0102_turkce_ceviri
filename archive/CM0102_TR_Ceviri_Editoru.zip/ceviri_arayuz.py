# -*- coding: utf-8 -*-
"""CM0102 Turkce Ceviri Editoru (pencereli surum). Sadece Python 3 gerekir (tkinter Python ile gelir)."""
import time, os, re, shutil, zipfile
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import xml.etree.ElementTree as ET
from xml.sax.saxutils import escape

EXPECT_SIZE = 205757382
TAG = re.compile(r'<\s*%[^>]*>')
SUBS = str.maketrans({'ş':'s','Ş':'S','ğ':'g','Ğ':'G','ı':'i','İ':'I'})
HEAD = ['Sira','Grup','Ofset','Kapasite','Dogrulama','Ingilizce','Orijinal Norvecce','Turkce','Not','Guncelleme','Guncelleyen','Onay','OnayTarihi','Onaylayan','SonraBak','Kaynak','Onceki Claude','Eski v65','Ilk Ceviri v66','Alternatif Notu']
ALTS = [('Onceki Claude', 'Onceki ceviri (Claude)'), ('Eski v65', 'Eski ceviri (v65)'), ('Ilk Ceviri v66', 'Ilk ceviri (v66)')]

# ---------------- xlsx okuma / yazma (kutuphanesiz) ----------------
def _col(ref):
    n = 0
    for ch in ref:
        if ch.isalpha(): n = n * 26 + (ord(ch.upper()) - 64)
        else: break
    return n - 1

def read_xlsx(path):
    ns = '{http://schemas.openxmlformats.org/spreadsheetml/2006/main}'
    z = zipfile.ZipFile(path)
    shared = []
    if 'xl/sharedStrings.xml' in z.namelist():
        root = ET.fromstring(z.read('xl/sharedStrings.xml'))
        for si in root.iter(ns + 'si'):
            shared.append(''.join(t.text or '' for t in si.iter(ns + 't')))
    sheet = 'xl/worksheets/sheet1.xml'
    if sheet not in z.namelist():
        sheet = sorted(n for n in z.namelist() if n.startswith('xl/worksheets/sheet'))[0]
    out = []
    for _, el in ET.iterparse(z.open(sheet)):
        if el.tag == ns + 'row':
            row = {}
            for c in el.findall(ns + 'c'):
                t = c.get('t'); v = c.find(ns + 'v')
                if t == 'inlineStr': val = ''.join(x.text or '' for x in c.iter(ns + 't'))
                elif v is None: val = None
                elif t == 's': val = shared[int(v.text)]
                else: val = v.text
                row[_col(c.get('r'))] = val
            out.append(row); el.clear()
    return out

def colname(i):
    s = ''; i += 1
    while i:
        i, r = divmod(i - 1, 26); s = chr(65 + r) + s
    return s

def write_xlsx(path, rows):
    def cell(ref, v):
        if v is None or v == '': return ''
        if isinstance(v, int): return '<c r="%s"><v>%d</v></c>' % (ref, v)
        t = re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f]', '', str(v))
        return '<c r="%s" t="inlineStr"><is><t xml:space="preserve">%s</t></is></c>' % (ref, escape(t))
    parts = ['<row r="1">' + ''.join(cell(colname(i) + '1', h) for i, h in enumerate(HEAD)) + '</row>']
    for n, r in enumerate(rows, 2):
        parts.append('<row r="%d">' % n + ''.join(cell(colname(i) + str(n), r.get(h)) for i, h in enumerate(HEAD)) + '</row>')
    sheet = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
             '<cols><col min="6" max="8" width="55" customWidth="1"/></cols><sheetData>' + ''.join(parts) + '</sheetData></worksheet>')
    with zipfile.ZipFile(path, 'w', zipfile.ZIP_DEFLATED) as z:
        z.writestr('[Content_Types].xml', '<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>')
        z.writestr('_rels/.rels', '<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>')
        z.writestr('xl/workbook.xml', '<?xml version="1.0" encoding="UTF-8"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Ceviri" sheetId="1" r:id="rId1"/></sheets></workbook>')
        z.writestr('xl/_rels/workbook.xml.rels', '<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>')
        z.writestr('xl/worksheets/sheet1.xml', sheet)

def load_rows(path):
    data = read_xlsx(path)
    head = {str(v).strip(): k for k, v in data[0].items() if v is not None}
    for n in ['Sira', 'Grup', 'Ofset', 'Kapasite', 'Dogrulama', 'Turkce']:
        if n not in head: raise ValueError("Excel'de '%s' sutunu yok." % n)
    rows = []
    for r in data[1:]:
        g = lambda n: r.get(head[n]) if n in head else None
        if g('Sira') is None: continue
        rows.append({'Sira': int(float(g('Sira'))), 'Grup': int(float(g('Grup'))), 'Ofset': int(float(g('Ofset'))),
                     'Kapasite': int(float(g('Kapasite'))), 'Dogrulama': str(g('Dogrulama') or ''),
                     'Ingilizce': g('Ingilizce') or '', 'Orijinal Norvecce': g('Orijinal Norvecce') or '',
                     'Turkce': g('Turkce') or '', 'Not': g('Not') or '',
                     'Guncelleme': g('Guncelleme') or '', 'Guncelleyen': g('Guncelleyen') or '',
                     'Onay': g('Onay') or '', 'OnayTarihi': g('OnayTarihi') or '', 'Onaylayan': g('Onaylayan') or '', 'SonraBak': g('SonraBak') or '',
                     'Kaynak': g('Kaynak') or '', 'Onceki Claude': g('Onceki Claude') or '', 'Eski v65': g('Eski v65') or '',
                     'Ilk Ceviri v66': g('Ilk Ceviri v66') or '', 'Alternatif Notu': g('Alternatif Notu') or ''})
    return rows

# ---------------- cekirdek mantik ----------------
def build_field(turkce, orig, cap, safe=False):
    """-> (field_bytes veya None, durum_metni, bayt, kapasite)"""
    t = (turkce or '').replace('\r\n', '\n').replace('\r', '\n')
    if not t.strip(): return None, 'bos', 0, cap
    while t.startswith('\n\n'): t = t[2:]
    t = t.replace('<ARG>', '\x08')
    body = TAG.sub('\x08', t).translate(SUBS).encode('cp1252', errors='replace')
    no = orig.count(b'\x08'); nt = body.count(b'\x08')
    field = (b'\n\n' if orig.startswith(b'\n\n') else b'') + body + b'\x00'
    if nt > no: return None, 'HATA: degisken sayisi fazla (%d > %d), oyun cokebilir' % (nt, no), len(field), cap
    if len(field) > cap: return None, 'HATA: sigmiyor', len(field), cap
    if safe and len(field) > len(orig) + 1: return None, 'guvenli modda atlanir (orijinalden uzun)', len(field), cap
    return field, 'tamam', len(field), cap

# ---- yazma cekirdegi: Norvecce metin + degisken sira tablosu ----
TAGX = re.compile(r'<\s*%[^>]*>|<ARG>')
FFRUN = re.compile(rb'\xff{15,}')
def tnorm(t): return re.sub(r'\s+', ' ', t).strip()

def slot_info(data, ofs):
    """Norvecce alan bilgisi: (metin, slot_sonu, eski_perm, eski_tablo_baslangici)"""
    q = data.index(b'\x00', ofs); text = data[ofs:q]
    m = FFRUN.search(data, ofs, ofs + 2400)
    nf = m.start() if m else None
    if nf is None: return text, None, [], None
    k = text.count(b'\x08'); t = nf - 1 - 4 * k
    if data[t] == 0x20:
        perm = [int.from_bytes(data[t+1+4*i:t+5+4*i], 'little') for i in range(k)]
        return text, nf, perm, t
    return text, nf, [], None      # bos alan: tablo yok

def eng_tags(en):
    return [tnorm(t) for t in re.findall(r'<\s*%[^>]*>', en)]

def build_v2(turkce, en, data, ofs):
    """-> (yazilacak [(ofs, bytes)], durum, metin_bayt, kapasite)"""
    text0, nf, perm0, tstart = slot_info(data, ofs)
    if nf is None: return None, 'HATA: alan sonu bulunamadi', 0, 0
    t = (turkce or '').replace('\r\n', '\n').replace('\r', '\n')
    if not t.strip(): return None, 'bos', 0, nf - ofs
    while t.startswith('\n\n'): t = t[2:]
    et = eng_tags(en); used = [False] * len(et); perm = []; argi = 0
    parts = []; pos = 0
    for m in TAGX.finditer(t):
        parts.append(t[pos:m.start()]); pos = m.end()
        tg = m.group()
        if tg == '<ARG>':
            idx = None
            if argi < len(perm0) and perm0[argi] < len(et) and not used[perm0[argi]]: idx = perm0[argi]
            argi += 1
            if idx is None:
                idx = next((i for i in range(len(et)) if not used[i]), None)
        else:
            n = tnorm(tg); idx = next((i for i in range(len(et)) if et[i] == n and not used[i]), None)
            if idx is None:
                return None, 'HATA: ingilizcede olmayan ya da fazla etiket: %s' % tg[:40], 0, nf - ofs
        if idx is None: return None, 'HATA: degisken sayisi fazla (ingilizcede %d)' % len(et), 0, nf - ofs
        used[idx] = True; perm.append(idx); parts.append('\x08')
    parts.append(t[pos:])
    body = ''.join(parts).translate(SUBS).encode('cp1252', errors='replace')
    field = (b'\n\n' if text0.startswith(b'\n\n') else b'') + body + b'\x00'
    trailer = b' ' + b''.join(p.to_bytes(4, 'little') for p in perm)
    cap = nf - ofs - len(trailer)
    if len(field) > cap: return None, 'HATA: sigmiyor (%d > %d)' % (len(field), cap), len(field), cap
    zstart = min(tstart if tstart is not None else nf, nf - len(trailer))
    writes = [(ofs, field), (zstart, b'\x00' * (nf - len(trailer) - zstart) + trailer)]
    if ofs + len(field) > zstart: return None, 'HATA: sigmiyor', len(field), cap
    return writes, 'tamam', len(field), cap

def orig_bytes(data, ofs):
    q = ofs
    while data[q] != 0: q += 1
    return data[ofs:q]

# ---------------- arayuz ----------------
class App:
    def __init__(self, root):
        self.root = root; root.title('CM0102 Turkce Ceviri Editoru'); root.geometry('1280x780')
        self.rows = []; self.xlsx = None; self.ldb = None; self.data = None; self.dirty = False
        self.view = []; self.cur = None
        self.user_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'kullanici.txt')
        try: u0 = open(self.user_file, encoding='utf-8').read().strip()
        except OSError: u0 = ''
        self.user = tk.StringVar(value=u0)
        self.build()
        p = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'ceviriler.xlsx')
        if os.path.exists(p): self.open_xlsx(p)

    def build(self):
        r = self.root
        r.title('CM 01/02 | İngilizce - Türkçe Çeviri Kontrol')
        r.geometry('1440x850')
        style = ttk.Style()
        try: style.theme_use('clam')
        except tk.TclError: pass
        style.configure('Treeview', rowheight=29, font=('Segoe UI', 10))
        style.configure('Treeview.Heading', font=('Segoe UI', 10, 'bold'))
        style.configure('Title.TLabel', font=('Segoe UI', 16, 'bold'))
        top = ttk.Frame(r, padding=10); top.pack(fill='x')
        ttk.Label(top, text='Çeviri kontrol merkezi', style='Title.TLabel').pack(side='left', padx=(0,20))
        ttk.Button(top, text='Excel aç', command=self.pick_xlsx).pack(side='left', padx=3)
        ttk.Button(top, text='Orijinal .ldb seç', command=self.pick_ldb).pack(side='left', padx=3)
        ttk.Button(top, text='Excel’e kaydet  (Ctrl+S)', command=self.save).pack(side='right', padx=3)
        self.user = tk.StringVar(value=self.user.get())
        ttk.Entry(top, textvariable=self.user, width=18).pack(side='right', padx=4)
        ttk.Label(top, text='Düzenleyen').pack(side='right', padx=4)
        mid = ttk.Frame(r, padding=(10,0)); mid.pack(fill='x')
        self.lbl = ttk.Label(mid, text=''); self.lbl.pack(side='left')
        bar = ttk.Frame(r, padding=10); bar.pack(fill='x')
        ttk.Label(bar, text='Ara (İngilizce / Türkçe / sıra)').pack(side='left')
        self.q=tk.StringVar()
        search=ttk.Entry(bar,textvariable=self.q,width=44); search.pack(side='left',padx=8)
        self.q.trace_add('write',lambda *_:self.refresh())
        self.f=tk.StringVar(value='Hepsi')
        opts=['Hepsi','Çevrilmemiş (boş)','Sorunlu','Düzenlenenler','Onaylanmamış','Onaylı','Sonra bak','Eski çeviriden alınanlar','Alternatif çeviri bulunanlar']
        cb=ttk.Combobox(bar,textvariable=self.f,values=opts,state='readonly',width=27)
        cb.pack(side='left',padx=6);cb.bind('<<ComboboxSelected>>',lambda e:self.refresh())
        self.cnt=ttk.Label(bar,text='');self.cnt.pack(side='right')
        pane=ttk.PanedWindow(r,orient='horizontal');pane.pack(fill='both',expand=True,padx=10,pady=5)
        left=ttk.Frame(pane);pane.add(left,weight=4)
        self.tv=ttk.Treeview(left,columns=('sira','en','tr','durum','isaret'),show='headings',selectmode='browse')
        for c,t,w in [('sira','#',62),('en','İngilizce',340),('tr','Türkçe',340),('durum','Durum',90),('isaret','Onay',58)]:
            self.tv.heading(c,text=t);self.tv.column(c,width=w,minwidth=50,stretch=(c in ('en','tr')))
        scroll=ttk.Scrollbar(left,command=self.tv.yview);self.tv.configure(yscrollcommand=scroll.set)
        self.tv.pack(side='left',fill='both',expand=True);scroll.pack(side='right',fill='y')
        self.tv.bind('<<TreeviewSelect>>',self.on_select)
        self.tv.tag_configure('hata',foreground='#ba1b1b')
        right=ttk.Frame(pane,padding=(12,4));pane.add(right,weight=3)
        self.hdr=ttk.Label(right,text='Soldan bir satır seçin',font=('Segoe UI',11,'bold'),wraplength=520)
        self.hdr.pack(anchor='w',pady=(0,14))
        ttk.Label(right,text='İNGİLİZCE • KAYNAK',font=('Segoe UI',10,'bold')).pack(anchor='w')
        self.t_en=tk.Text(right,height=8,wrap='word',state='disabled',bg='#eff3f8',relief='flat',font=('Segoe UI',11),padx=12,pady=10)
        self.t_en.pack(fill='both',expand=True,pady=(6,15))
        ttk.Label(right,text='TÜRKÇE • DÜZENLENEBİLİR',font=('Segoe UI',10,'bold')).pack(anchor='w')
        self.t_tr=tk.Text(right,height=10,wrap='word',undo=True,font=('Segoe UI',11),padx=12,pady=10)
        self.t_tr.pack(fill='both',expand=True,pady=(6,6))
        self.t_tr.bind('<<Modified>>',self.text_modified)
        self.info=ttk.Label(right,text='',wraplength=540);self.info.pack(anchor='w',pady=5)
        altf=ttk.Frame(right);altf.pack(fill='x',pady=(8,3))
        ttk.Label(altf,text='Diğer Türkçe önerisi:').pack(side='left')
        self.altv=tk.StringVar();self.altcb=ttk.Combobox(altf,textvariable=self.altv,state='readonly',width=25)
        self.altcb.pack(side='left',padx=6);self.altcb.bind('<<ComboboxSelected>>',lambda e:self.show_alt())
        ttk.Button(altf,text='Çeviriye aktar',command=self.use_alt).pack(side='right')
        self.alt_l=ttk.Label(right,text='',foreground='#a60',wraplength=520);self.alt_l.pack(anchor='w')
        self.t_alt=tk.Text(right,height=3,wrap='word',state='disabled',bg='#fff8e6',relief='flat',font=('Segoe UI',10),padx=8,pady=6)
        self.t_alt.pack(fill='x')
        nav=ttk.Frame(right);nav.pack(fill='x',pady=10)
        ttk.Button(nav,text='← Önceki',command=lambda:self.move(-1)).pack(side='left',padx=2)
        ttk.Button(nav,text='Sonraki →',command=lambda:self.move(1)).pack(side='left',padx=2)
        self.bok=ttk.Button(nav,text='✓ Onayla',command=self.toggle_ok);self.bok.pack(side='left',padx=5)
        self.bfl=ttk.Button(nav,text='⚑ Sonra bak',command=self.toggle_flag);self.bfl.pack(side='left',padx=2)
        ttk.Button(nav,text='Temizle',command=self.clear_row).pack(side='right')
        self.okl=ttk.Label(right,text='');self.okl.pack(anchor='w')
        wf=ttk.LabelFrame(r,text='Opsiyonel • oyun dosyası oluşturma (yalnızca eşleşen orijinal .ldb)',padding=8)
        wf.pack(fill='x',padx=10,pady=(3,9))
        ttk.Label(wf,text='Satırlar').pack(side='left')
        self.a=tk.StringVar(value='1');self.b=tk.StringVar(value='99999')
        ttk.Entry(wf,textvariable=self.a,width=7).pack(side='left',padx=4)
        ttk.Label(wf,text='–').pack(side='left')
        ttk.Entry(wf,textvariable=self.b,width=7).pack(side='left',padx=4)
        self.onlyok=tk.BooleanVar(value=True);self.safe=tk.BooleanVar(value=False)
        ttk.Checkbutton(wf,text='Yalnızca onaylananlar',variable=self.onlyok).pack(side='left',padx=10)
        ttk.Checkbutton(wf,text='Güvenli mod',variable=self.safe).pack(side='left',padx=6)
        ttk.Button(wf,text='language.ldb oluştur',command=self.make_ldb).pack(side='left',padx=9)
        self.wl=ttk.Label(wf,text='');self.wl.pack(side='left')
        r.bind('<Control-s>',lambda e:self.save())
        r.bind('<Control-Return>',lambda e:self.move(1))
        r.bind('<Control-Shift-Return>',lambda e:self.approve_next())
        r.protocol('WM_DELETE_WINDOW',self.on_close)

    def text_modified(self,event=None):
        if self.t_tr.edit_modified():
            self.t_tr.edit_modified(False)
            self.on_edit()

    def pick_xlsx(self):
        p = filedialog.askopenfilename(title='Ceviri Excel dosyasi', filetypes=[('Excel', '*.xlsx')])
        if p: self.open_xlsx(p)

    def open_xlsx(self, p):
        try: self.rows = load_rows(p)
        except Exception as ex:
            messagebox.showerror('Hata', 'Excel okunamadi:\n%s' % ex); return
        self.xlsx = p; self.dirty = False; self.cur = None; self.update_label(); self.refresh()

    def pick_ldb(self):
        p = filedialog.askopenfilename(title='Orijinal language.ldb', filetypes=[('ldb', '*.ldb'), ('Hepsi', '*.*')])
        if not p: return
        if os.path.getsize(p) != EXPECT_SIZE and not messagebox.askyesno('Uyari', 'Dosya boyutu beklenenden farkli. Yine de kullanilsin mi?'): return
        self.ldb = p; self.data = None; self.update_label(); self.refresh()

    def get_data(self):
        if self.data is None and self.ldb:
            with open(self.ldb, 'rb') as f: self.data = f.read()
        return self.data

    def update_label(self):
        self.lbl.config(text='Excel: %s   |   ldb: %s' % (os.path.basename(self.xlsx) if self.xlsx else '-',
                        os.path.basename(self.ldb) if self.ldb else 'secilmedi (dosya olusturmak icin gerekli)'))

    def row_orig(self, r):
        d = self.get_data()
        if d is None: return None
        try: return orig_bytes(d, r['Ofset'])
        except Exception: return None

    def check(self, r, safe=False):
        t = r['Turkce'] or ''
        d = self.get_data()
        et = eng_tags(r['Ingilizce'])
        if d is None:
            # ldb secilmeden yaklasik kontrol: etiketler ingilizcede var mi, sayi asiliyor mu
            if not t.strip(): return None, 'bos', 0, r['Kapasite'], 0, len(et)
            rest = list(et); k = 0
            for m in TAGX.finditer(t):
                k += 1
                if m.group() == '<ARG>': continue
                n = tnorm(m.group())
                if n in rest: rest.remove(n)
                else: return None, 'HATA: ingilizcede olmayan ya da fazla etiket', 0, r['Kapasite'], k, len(et)
            if k > len(et): return None, 'HATA: degisken sayisi fazla', 0, r['Kapasite'], k, len(et)
            return True, 'tamam (yaklasik)', len(TAGX.sub('\x08', t).encode('cp1252', 'replace')) + 1, r['Kapasite'], k, len(et)
        w, st, n, cap = build_v2(t, r['Ingilizce'], d, r['Ofset'])
        k = len(TAGX.findall(t)) if w else len(TAGX.findall(t))
        if w and safe and n > len(orig_bytes(d, r['Ofset'])) + 1:
            return None, 'guvenli modda atlanir (orijinalden uzun)', n, cap, k, len(et)
        return w, st, n, cap, k, len(et)

    def row_status(self, r):
        if not (r['Turkce'] or '').strip(): return 'bos'
        return 'tamam' if self.check(r)[0] else 'HATA'

    @staticmethod
    def short(s): return (s or '').replace('\n', ' ⏎ ')[:80]

    def refresh(self):
        q = self.q.get().lower(); flt = self.f.get(); self.view = []
        for r in self.rows:
            if q and q not in (str(r['Sira']) + ' ' + r['Ingilizce'] + ' ' + r['Turkce']).lower(): continue
            if flt == 'Çevrilmemiş (boş)' and (r['Turkce'] or '').strip(): continue
            if flt == 'Sorunlu' and self.row_status(r) != 'HATA': continue
            if flt == 'Notlu satirlar' and not r['Not']: continue
            if flt == 'Duzenlenenler' and not r.get('_edit'): continue
            if flt == 'Onaylanmamış' and (r['Onay'] or not (r['Turkce'] or '').strip()): continue
            if flt == 'Onaylı' and not r['Onay']: continue
            if flt == 'Sonra bak' and not r['SonraBak']: continue
            if flt == 'Eski çeviriden alınanlar' and r['Kaynak'] != 'v65': continue
            if flt == 'Alternatif çeviri bulunanlar' and not (r['Eski v65'] or r['Onceki Claude'] or r['Ilk Ceviri v66']): continue
            if flt == 'Ilk ceviri (v66) farkli olanlar' and not r['Ilk Ceviri v66']: continue
            self.view.append(r)
        self.tv.delete(*self.tv.get_children())
        for i, r in enumerate(self.view):
            st = self.row_status(r)
            self.tv.insert('', 'end', iid=str(i), tags=(('hata',) if st == 'HATA' else ()),
                           values=(r['Sira'], self.short(r['Ingilizce']), self.short(r['Turkce']), st, self.mark(r)))
        self.upd_cnt()

    @staticmethod
    def mark(r): return '✓' if r['Onay'] else ('⚑' if r['SonraBak'] else '')

    def upd_cnt(self):
        self.cnt.config(text='%d satir listede - onayli %d / %d%s' % (len(self.view), sum(1 for r in self.rows if r['Onay']), len(self.rows),
                        ''))

    def on_select(self, e=None):
        sel = self.tv.selection()
        if not sel: return
        self.cur = self.view[int(sel[0])]; r = self.cur
        meta = ('   |   Son guncelleme: %s - %s' % (r.get('Guncelleme') or '?', r.get('Guncelleyen') or '?')) if r.get('Guncelleme') else ''
        self.hdr.config(text='Sira %d   (grup %d)   %s%s' % (r['Sira'], r['Grup'], ('  -  ' + r['Not']) if r['Not'] else '', meta))
        self.upd_ok()
        for w, txt in ((self.t_en, r['Ingilizce']),):
            w.config(state='normal'); w.delete('1.0', 'end'); w.insert('1.0', txt); w.config(state='disabled')
        opts = [lbl for col, lbl in ALTS if r[col]]
        self.altcb.config(values=opts); self.altv.set(opts[0] if opts else 'alternatif yok'); self.show_alt()
        self.t_tr.delete('1.0', 'end'); self.t_tr.insert('1.0', r['Turkce']); self.t_tr.edit_reset(); self.t_tr.edit_modified(False); self.upd_info()

    def alt_col(self):
        for col, lbl in ALTS:
            if lbl == self.altv.get(): return col
        return None

    def show_alt(self):
        r = self.cur; col = self.alt_col() if r else None
        txt = r[col] if col else ''
        note = r['Alternatif Notu'] if r else ''
        self.alt_l.config(text=('UYARI: ' + note) if (col and note and col != 'Onceki Claude') else '')
        self.t_alt.config(state='normal'); self.t_alt.delete('1.0', 'end'); self.t_alt.insert('1.0', txt); self.t_alt.config(state='disabled')

    def use_alt(self):
        col = self.alt_col() if self.cur else None
        if not col or not self.cur[col]: return
        self.t_tr.delete('1.0', 'end'); self.t_tr.insert('1.0', self.cur[col]); self.on_edit()

    def upd_ok(self):
        r = self.cur
        if not r: return
        self.bok.config(text='✓ Onaylandi (kaldir)' if r['Onay'] else '✓ Onayla (Ctrl+Shift+Enter)')
        self.bfl.config(text='⚑ Isaretli (kaldir)' if r['SonraBak'] else '⚑ Sonra bak')
        self.okl.config(text=('Onaylandi: %s - %s' % (r['OnayTarihi'] or '?', r['Onaylayan'] or '?')) if r['Onay'] else 'Onaylanmadi')

    def refresh_item(self):
        sel = self.tv.selection()
        if sel:
            self.tv.item(sel[0], values=(self.cur['Sira'], self.short(self.cur['Ingilizce']), self.short(self.cur['Turkce']), self.row_status(self.cur), self.mark(self.cur)))
        self.upd_cnt(); self.upd_ok()

    def toggle_ok(self):
        r = self.cur
        if not r: return False
        if r['Onay']:
            r['Onay'] = r['OnayTarihi'] = r['Onaylayan'] = ''
        else:
            if self.row_status(r) != 'tamam':
                messagebox.showwarning('Onaylanamaz', 'Bos ya da hatali satir onaylanamaz.'); return False
            self.save_user()
            r['Onay'] = 'Evet'; r['OnayTarihi'] = time.strftime('%Y-%m-%d %H:%M'); r['Onaylayan'] = self.user.get().strip() or 'bilinmiyor'; r['SonraBak'] = ''
        self.dirty = True; self.refresh_item(); return True

    def toggle_flag(self):
        r = self.cur
        if not r: return
        r['SonraBak'] = '' if r['SonraBak'] else 'Evet'; self.dirty = True; self.refresh_item()

    def approve_next(self):
        if self.cur and (self.cur['Onay'] or self.toggle_ok()): self.move(1)
        return 'break'

    def save_user(self):
        try: open(self.user_file, 'w', encoding='utf-8').write(self.user.get().strip())
        except OSError: pass

    def on_edit(self):
        if not self.cur: return
        txt = self.t_tr.get('1.0', 'end-1c')
        if txt != self.cur['Turkce']:
            self.cur['Turkce'] = txt; self.cur['_edit'] = True; self.dirty = True
            self.save_user()
            if self.cur['Onay']: self.cur['Onay'] = self.cur['OnayTarihi'] = self.cur['Onaylayan'] = ''
            self.cur['Guncelleme'] = time.strftime('%Y-%m-%d %H:%M'); self.cur['Guncelleyen'] = self.user.get().strip() or 'bilinmiyor'
            r = self.cur; self.upd_ok(); self.upd_cnt()
            self.hdr.config(text='Sira %d   (grup %d)   %s   |   Son guncelleme: %s - %s' % (r['Sira'], r['Grup'], ('  -  ' + r['Not']) if r['Not'] else '', r['Guncelleme'], r['Guncelleyen']))
        self.upd_info()
        sel = self.tv.selection()
        if sel:
            st = self.row_status(self.cur)
            self.tv.item(sel[0], tags=(('hata',) if st == 'HATA' else ()),
                         values=(self.cur['Sira'], self.short(self.cur['Ingilizce']), self.short(self.cur['Turkce']), st, self.mark(self.cur)))

    def upd_info(self):
        r = self.cur
        if not r: return
        w, st, n, cap, k, ne = self.check(r)
        extra = '' if self.get_data() is not None else '    (kesin kontrol icin orijinal .ldb secin)'
        self.info.config(text='Bayt: %d / %d    Degisken: %d (Ingilizcede %d)    Durum: %s%s' % (n, cap, k, ne, st, extra),
                         foreground=('#080' if w else ('#888' if st == 'bos' else '#c00')))

    def move(self, d):
        sel = self.tv.selection()
        i = (int(sel[0]) if sel else -1) + d
        kids = self.tv.get_children()
        if 0 <= i < len(kids):
            self.tv.selection_set(str(i)); self.tv.see(str(i)); self.tv.focus(str(i))
        self.t_tr.focus_set(); return 'break'

    def clear_row(self):
        if not self.cur: return
        self.t_tr.delete('1.0', 'end'); self.on_edit()

    def save(self):
        if not self.xlsx: return
        try:
            bak = self.xlsx + '.bak'
            if not os.path.exists(bak): shutil.copyfile(self.xlsx, bak)
            write_xlsx(self.xlsx, self.rows); self.dirty = False
            self.wl.config(text='Excel kaydedildi.')
        except PermissionError:
            messagebox.showerror('Hata', 'Excel dosyasi baska bir programda acik. Kapatip tekrar deneyin.')

    def make_ldb(self):
        d = self.get_data()
        if d is None:
            messagebox.showwarning('Eksik', 'Once "Orijinal language.ldb sec…" ile degistirilmemis dosyayi secin.'); return
        try: a, b = int(self.a.get()), int(self.b.get())
        except ValueError:
            messagebox.showerror('Hata', 'Sira araligi sayi olmali.'); return
        if len(d) != EXPECT_SIZE:
            messagebox.showerror('Uyumsuz dosya', 'Seçilen language.ldb boyutu bu Excel tablosunun referans dosyasıyla uyuşmuyor. Farklı bir oyun sürümüne yazma engellendi.'); return
        out = bytearray(d); w = sk = 0; notes = []
        for r in self.rows:
            if not (a <= r['Sira'] <= b): continue
            if self.onlyok.get() and not r['Onay']: continue
            o = orig_bytes(d, r['Ofset'])
            if o[:12].hex() != r['Dogrulama']:
                messagebox.showerror('Hata', 'Sira %d icin secilen .ldb Excel ile uyusmuyor. Orijinal, degistirilmemis dosyayi secin.' % r['Sira']); return
            f, s, n, c, k, ne = self.check(r, self.safe.get())
            if not f:
                if s != 'bos': sk += 1; notes.append('Sira %d: %s' % (r['Sira'], s))
                continue
            for o2, bb in f: out[o2:o2 + len(bb)] = bb
            w += 1
        p = filedialog.asksaveasfilename(title='Cikti dosyasi', defaultextension='.ldb', initialfile='language.ldb', filetypes=[('ldb', '*.ldb')])
        if not p: return
        if self.ldb and os.path.abspath(p) == os.path.abspath(self.ldb):
            messagebox.showerror('Hata', 'Orijinal dosyanin uzerine yazilamaz. Baska bir isim secin.'); return
        with open(p, 'wb') as f: f.write(out)
        msg = '%d satir yazildi, %d atlandi.\n%s' % (w, sk, p)
        if notes: msg += '\n\nAtlananlar (ilk 15):\n' + '\n'.join(notes[:15])
        self.wl.config(text='%d yazildi, %d atlandi' % (w, sk)); messagebox.showinfo('Tamam', msg)

    def on_close(self):
        if self.dirty:
            ans = messagebox.askyesnocancel('Kaydet', 'Kaydedilmemis degisiklikler var. Excel’e kaydedilsin mi?')
            if ans is None: return
            if ans: self.save()
        self.root.destroy()

if __name__ == '__main__':
    root = tk.Tk()
    try: ttk.Style().theme_use('vista')
    except Exception: pass
    App(root); root.mainloop()
