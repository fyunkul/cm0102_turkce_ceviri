# -*- coding: utf-8 -*-
"""CM0102 English/Turkish CSV review tool. Does not patch binary files."""
import csv, os, re, shutil, datetime, tkinter as tk
from tkinter import ttk, filedialog, messagebox
HEAD=['ID','English (Original)','Türkçe (Çeviri)','Durum']
TAG=re.compile(r'<\s*%[^>]*>|<ARG>')
class Editor:
 def __init__(self,root):
  self.root=root;root.title('CM0102 | İngilizce - Türkçe Çeviri Kontrol (CSV)');root.geometry('1420x850')
  self.path='';self.rows=[];self.filtered=[];self.selected=None;self.dirty=False
  top=ttk.Frame(root,padding=8);top.pack(fill='x')
  ttk.Button(top,text='CSV Aç',command=self.open_dialog).pack(side='left',padx=4)
  ttk.Button(top,text='Kaydet (Ctrl+S)',command=self.save).pack(side='left',padx=4)
  ttk.Button(top,text='Farklı Kaydet',command=self.save_as).pack(side='left',padx=4)
  ttk.Button(top,text='Sonraki',command=lambda:self.step(1)).pack(side='right',padx=4)
  ttk.Button(top,text='Önceki',command=lambda:self.step(-1)).pack(side='right',padx=4)
  bar=ttk.Frame(root,padding=8);bar.pack(fill='x')
  ttk.Label(bar,text='İngilizce / Türkçe / ID ara:').pack(side='left')
  self.search=tk.StringVar();ent=ttk.Entry(bar,textvariable=self.search,width=55);ent.pack(side='left',padx=8);self.search.trace_add('write',lambda *_:self.refresh())
  self.filter=tk.StringVar(value='Hepsi');box=ttk.Combobox(bar,textvariable=self.filter,state='readonly',values=['Hepsi','Çevrildi','Korundu (özel ad/kod)','Kontrol edildi','Kontrol edilecek','Etiket uyumsuzluğu','İngilizceyle aynı'],width=25);box.pack(side='left');box.bind('<<ComboboxSelected>>',lambda _:self.refresh())
  self.stats=ttk.Label(bar);self.stats.pack(side='right')
  frame=ttk.Frame(root);frame.pack(fill='both',expand=True,padx=8)
  self.tree=ttk.Treeview(frame,columns=('id','en','tr','state'),show='headings',height=13,selectmode='browse')
  for k,t,w in [('id','ID',70),('en','English',480),('tr','Türkçe',480),('state','Durum',170)]:self.tree.heading(k,text=t);self.tree.column(k,width=w,stretch=k!='id')
  ys=ttk.Scrollbar(frame,orient='vertical',command=self.tree.yview);self.tree.configure(yscrollcommand=ys.set);self.tree.pack(side='left',fill='both',expand=True);ys.pack(side='left',fill='y');self.tree.bind('<<TreeviewSelect>>',self.choose)
  lower=ttk.Frame(root,padding=8);lower.pack(fill='both',expand=True)
  left=ttk.LabelFrame(lower,text='İngilizce (salt okunur)',padding=5);left.pack(side='left',fill='both',expand=True,padx=(0,5))
  right=ttk.LabelFrame(lower,text='Türkçe (düzenlenebilir)',padding=5);right.pack(side='left',fill='both',expand=True)
  self.en=tk.Text(left,wrap='word',font=('Segoe UI',11),height=12);self.en.pack(fill='both',expand=True);self.en.configure(state='disabled')
  self.tr=tk.Text(right,wrap='word',font=('Segoe UI',11),height=12);self.tr.pack(fill='both',expand=True)
  foot=ttk.Frame(root,padding=8);foot.pack(fill='x')
  ttk.Button(foot,text='Değişikliği uygula',command=self.commit).pack(side='left',padx=3)
  ttk.Button(foot,text='Kontrol edildi',command=lambda:self.set_status('Kontrol edildi')).pack(side='left',padx=3)
  ttk.Button(foot,text='Kontrol edilecek',command=lambda:self.set_status('Kontrol edilecek')).pack(side='left',padx=3)
  ttk.Button(foot,text='Çevrildi',command=lambda:self.set_status('Çevrildi')).pack(side='left',padx=3)
  self.note=ttk.Label(foot,text='');self.note.pack(side='left',padx=15)
  root.bind('<Control-s>',lambda _:self.save());root.protocol('WM_DELETE_WINDOW',self.close)
  default=os.path.join(os.path.dirname(__file__),'language_EN_TR_v66.csv')
  if os.path.isfile(default):self.open_file(default)
 def open_dialog(self):
  p=filedialog.askopenfilename(filetypes=[('CSV','*.csv')]);
  if p:self.open_file(p)
 def open_file(self,p):
  if self.dirty and not messagebox.askyesno('Kaydedilmemiş değişiklikler','Değişiklikler kaydedilmedi. Devam edilsin mi?'):return
  try:
   with open(p,encoding='utf-8-sig',newline='') as f:rd=csv.DictReader(f,delimiter=';');data=list(rd);assert all(k in rd.fieldnames for k in HEAD),'Gerekli sütunlar yok'
  except Exception as e:messagebox.showerror('CSV açılamadı',str(e));return
  self.rows=data;self.path=p;self.dirty=False;self.selected=None;self.refresh()
 def problems(self,r):
  en=TAG.findall(r['English (Original)']);tr=TAG.findall(r['Türkçe (Çeviri)']);msg=[]
  if len(en)!=len(tr):msg.append(f'Etiket sayısı uyuşmuyor: EN {len(en)}, TR {len(tr)}')
  if not r['Türkçe (Çeviri)'].strip():msg.append('Türkçe boş')
  return '; '.join(msg) or 'Etiket sayısı uygun'
 def refresh(self):
  if not self.rows:return
  q=self.search.get().casefold().strip();flt=self.filter.get();self.filtered=[]
  for i,r in enumerate(self.rows):
   if q and q not in (r['ID']+' '+r['English (Original)']+' '+r['Türkçe (Çeviri)']).casefold():continue
   if flt=='Etiket uyumsuzluğu' and len(TAG.findall(r['English (Original)']))==len(TAG.findall(r['Türkçe (Çeviri)'])):continue
   if flt=='İngilizceyle aynı' and r['English (Original)'].strip()!=r['Türkçe (Çeviri)'].strip():continue
   if flt not in ('Hepsi','Etiket uyumsuzluğu','İngilizceyle aynı') and r['Durum']!=flt:continue
   self.filtered.append(i)
  self.tree.delete(*self.tree.get_children())
  for idx in self.filtered:
   r=self.rows[idx];self.tree.insert('', 'end',iid=str(idx),values=(r['ID'],r['English (Original)'].strip().replace('\n',' ')[:110],r['Türkçe (Çeviri)'].strip().replace('\n',' ')[:110],r['Durum']))
  self.stats.configure(text=f'Görüntülenen {len(self.filtered):,} / Toplam {len(self.rows):,}')
 def choose(self,_=None):
  sel=self.tree.selection()
  if not sel:return
  idx=int(sel[0]);
  if self.selected is not None and idx!=self.selected:self.commit(refresh=False)
  self.selected=idx;r=self.rows[idx];self.en.configure(state='normal');self.en.delete('1.0','end');self.en.insert('1.0',r['English (Original)']);self.en.configure(state='disabled');self.tr.delete('1.0','end');self.tr.insert('1.0',r['Türkçe (Çeviri)']);self.note.configure(text=f"ID {r['ID']} · {self.problems(r)}")
 def commit(self,refresh=True):
  if self.selected is None:return
  r=self.rows[self.selected];value=self.tr.get('1.0','end-1c')
  if value!=r['Türkçe (Çeviri)']:
   r['Türkçe (Çeviri)']=value;self.dirty=True
  self.note.configure(text=f"ID {r['ID']} · {self.problems(r)}")
  if refresh:self.refresh();self.tree.selection_set(str(self.selected));self.tree.see(str(self.selected))
 def set_status(self,s):
  if self.selected is None:return
  self.commit(refresh=False);self.rows[self.selected]['Durum']=s;self.dirty=True;self.refresh()
  if str(self.selected) in self.tree.get_children():self.tree.selection_set(str(self.selected));self.tree.see(str(self.selected))
 def step(self,d):
  self.commit(refresh=False)
  if not self.filtered:return
  try:ix=self.filtered.index(self.selected)
  except ValueError:ix=0
  idx=self.filtered[min(max(ix+d,0),len(self.filtered)-1)];self.tree.selection_set(str(idx));self.tree.see(str(idx));self.choose()
 def save_as(self):
  p=filedialog.asksaveasfilename(defaultextension='.csv',filetypes=[('CSV','*.csv')]);
  if p:self.save(p)
 def save(self,p=None):
  self.commit(refresh=False)
  if not self.rows:return
  p=p or self.path
  try:
   if os.path.exists(p):
    ts=datetime.datetime.now().strftime('%Y%m%d_%H%M%S');shutil.copy2(p,p+'.'+ts+'.bak')
   with open(p,'w',newline='',encoding='utf-8-sig') as f:
    w=csv.DictWriter(f,fieldnames=list(self.rows[0]),delimiter=';',extrasaction='ignore');w.writeheader();w.writerows(self.rows)
   self.path=p;self.dirty=False;self.root.title('CM0102 | '+os.path.basename(p));self.note.configure(text='Kaydedildi: '+p)
  except Exception as e:messagebox.showerror('Kayıt hatası',str(e))
 def close(self):
  self.commit(refresh=False)
  if self.dirty:
   choice=messagebox.askyesnocancel('Kaydedilmemiş değişiklikler','Değişiklikler kaydedilsin mi?')
   if choice is None:return
   if choice:self.save()
  self.root.destroy()
if __name__=='__main__':
 root=tk.Tk();Editor(root);root.mainloop()
