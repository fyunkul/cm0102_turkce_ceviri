# -*- coding: utf-8 -*-
"""Salt okunur LDB inceleme: yapisal adaylari raporlar; eksik Ingilizceyi tahmin etmez."""
import os, mmap, re, csv, argparse, collections
from ceviri_arayuz import load_rows
RECORD_SIZE = 20870
START = 14662

def inspect(ldb, excel, output):
    rows=load_rows(excel)
    known={r['Grup']:r for r in rows}
    count=collections.Counter()
    results=[]
    with open(ldb,'rb') as f:
        data=mmap.mmap(f.fileno(),0,access=mmap.ACCESS_READ)
        size=len(data)
        max_groups=max(0,(size-START)//RECORD_SIZE+1)
        for group in range(1,max_groups+1):
            expected=START+(group-1)*RECORD_SIZE
            if expected>=size:break
            # Yalnizca sabit offset'teki baytlari incele. Bir eslesme metin var demek degildir.
            raw=data[expected: min(expected+2048,size)]
            payload=raw.split(b'\0',1)[0]
            printable= bool(payload) and len(payload)<2048 and (sum(c in (8,9,10,13) or 32<=c<=126 or c>=160 for c in payload)/len(payload))>=0.90
            lead=raw[:2]==b'\n\n' or (payload and 32<=payload[0]<127)
            plausible=printable and lead and len(payload.strip())>=3
            row=known.get(group)
            # Dogrulama sadece orijinal slot icin; TR v2'de imzalar farkli olabilir.
            sigmatch=(data[expected:expected+12].hex()==row['Dogrulama']) if row else None
            if row: state='Excel kaydi mevcut'
            elif plausible:state='Excel disi metin adayi (dogrulanmadi)'
            else:state='Kayit tespit edilemedi'
            count[state]+=1
            if sigmatch:count['Imza eslesen']+=1
            if row and not sigmatch:count['Imza farkli']+=1
            # kayit listesini sinirlamadan raporla
            results.append(dict(Grup=group,Ofset=expected,Durum=state,ExcelSira=row['Sira'] if row else '',ImzaEslesiyor='Evet' if sigmatch else 'Hayir' if row else '',HamOnizleme=payload[:260].decode('cp1252','replace') if plausible else ''))
        data.close()
    with open(output,'w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=['Grup','Ofset','Durum','ExcelSira','ImzaEslesiyor','HamOnizleme'],delimiter=';');w.writeheader();w.writerows(results)
    return {'dosya_bayt':size,'hesaplanan_blok':len(results),'excel_satir':len(rows),'excel_en_yuksek_grup':max(known),**count}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('ldb');p.add_argument('xlsx');p.add_argument('-o','--output',default='tarama_raporu.csv');a=p.parse_args()
    print(inspect(a.ldb,a.xlsx,a.output));print('Rapor:',a.output)
