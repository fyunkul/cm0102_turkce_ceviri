@echo off
cd /d "%~dp0"
start "" pythonw ceviri_arayuz.py
if errorlevel 1 start "" pyw ceviri_arayuz.py
